# Parceria Comercial Estratégica — Janderson × FNW

> Ferramenta self-service de simulação financeira e validação de oportunidade de negócio.

🔗 **[Acesse a ferramenta ao vivo](https://SEU-USUARIO.github.io/fnw-parceria-comercial/)**

---

## O que é isso?

Esta aplicação é uma **proposta de parceria comercial interativa**, construída como ferramenta self-service para demonstrar:

- Capacidade de identificar e quantificar oportunidades de negócio
- Pensamento orientado a modelo de receita e escalabilidade
- Entrega autônoma de produto digital funcional
- Visão de parceiro, não apenas de colaborador

---

## Funcionalidades

| Recurso | Descrição |
|---|---|
| **Simulador de receita** | Sliders ajustáveis para ticket, parceiros/mês, retenção e base fixa |
| **Cálculo acumulado 12m** | Projeção com efeito de carteira crescente e retenção composta |
| **Comparação de cenários** | Conservador, Moderado e Agressivo com barras visuais |
| **Crivo estratégico** | Score de oportunidade em 8 dimensões (total: 74/80) |
| **Linha do tempo** | Período de validação de 90 dias detalhado |
| **Pitch executivo** | Argumentação de 30 segundos integrada |

---

## Modelo de remuneração (resumo)

| Evento | % | Quando |
|---|---|---|
| Fechamento novo parceiro | 20% | Mês 1 do contrato |
| Recorrência mensal (MRR) | 25% | Todo mês ativo |
| Expansão de conta | 10% | Na expansão |
| Renovação anual | 5% | Após 12 meses |

---

## Estrutura do projeto

```
fnw-parceria-comercial/
├── index.html   → Estrutura e conteúdo da aplicação
├── style.css    → Estilo visual (flat design, responsivo)
├── script.js    → Lógica do simulador e interatividade
└── README.md    → Esta documentação
```

---

## Como publicar no GitHub Pages

1. Crie um repositório público chamado `fnw-parceria-comercial`
2. Faça upload dos 4 arquivos (index.html, style.css, script.js, README.md)
3. Vá em **Settings → Pages**
4. Em **Source**, selecione **Deploy from a branch**
5. Escolha a branch `main` e pasta `/ (root)`
6. Clique em **Save**
7. Aguarde ~2 minutos — o link estará disponível no topo da página de Settings

---

## Autor

**Janderson da Silva Pereira** — Parceiro Comercial Estratégico  
Proposta apresentada à FNW em 18/06/2026
